//--------------------------------------------------------------------------------------
// File: HitEffect.cpp
//
// �Փˎ��̃G�t�F�N�g�\���N���X
//
// Date: 2019.1.5
// Author: Hideyasu Imase
//--------------------------------------------------------------------------------------
#include "pch.h"
#include "HitEffect.h"
#include "Game.h"
#include "GameWindow.h"

using namespace DirectX;
using namespace DirectX::SimpleMath;

// �G�t�F�N�g�\������
const float HitEffect::DISPLAY_TIME = 0.1f;

HitEffect::HitEffect()
	: m_gameWindow(nullptr), m_timer(0.0f)
{
	SetOt(GameWindow::OT_TOP);
}

void HitEffect::Initialize(GameWindow * gameWindow, DirectX::SimpleMath::Vector3 pos)
{
	m_gameWindow = gameWindow;
	m_pos = pos;
	m_timer = DISPLAY_TIME;
}

bool HitEffect::Update(float elapsedTime)
{
	// ���ԂɂȂ�����^�X�N�͏�����
	m_timer -= elapsedTime;
	if (m_timer <= 0.0f) return false;
	return true;
}

void HitEffect::Render()
{
	// ���_���
	VertexPositionColorTexture vertex[4] =
	{
		VertexPositionColorTexture(XMFLOAT3( 1.5f, 0.5f,  1.5f), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), XMFLOAT2(0.0f, 0.0f)),
		VertexPositionColorTexture(XMFLOAT3(-1.5f, 0.5f,  1.5f), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), XMFLOAT2(1.0f, 0.0f)),
		VertexPositionColorTexture(XMFLOAT3(-1.5f, 0.5f, -1.5f), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), XMFLOAT2(1.0f, 1.0f)),
		VertexPositionColorTexture(XMFLOAT3( 1.5f, 0.5f, -1.5f), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), XMFLOAT2(0.0f, 1.0f)),
	};
	Game* game = m_gameWindow->GetGame();

	// ���Z����
	game->GetContext()->OMSetBlendState(game->GetStates()->Additive(), nullptr, 0xFFFFFFFF);
	// �[�x�o�b�t�@�͂Ȃ�
	game->GetContext()->OMSetDepthStencilState(game->GetStates()->DepthNone(), 0);
	// �J�����O�͍�����
	game->GetContext()->RSSetState(game->GetStates()->CullCounterClockwise());

	Matrix world = Matrix::CreateTranslation(m_pos);
	m_gameWindow->GetBatchEffect()->SetWorld(world);
	m_gameWindow->GetBatchEffect()->SetView(m_gameWindow->GetViewMatrix());
	m_gameWindow->GetBatchEffect()->SetProjection(m_gameWindow->GetProjectionMatrix());
	m_gameWindow->GetBatchEffect()->SetTexture(m_gameWindow->GetHitEffectTexture());
	m_gameWindow->GetBatchEffect()->Apply(game->GetContext());
	game->GetContext()->IASetInputLayout(m_gameWindow->GetInputLayout());

	m_gameWindow->GetPrimitiveBatch()->Begin();
	m_gameWindow->GetPrimitiveBatch()->DrawQuad(vertex[0], vertex[1], vertex[2], vertex[3]);
	m_gameWindow->GetPrimitiveBatch()->End();
}
