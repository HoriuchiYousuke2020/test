//--------------------------------------------------------------------------------------
// File: InfoWindow.cpp
//
// ���E�C���h�E�N���X
//
// Date: 2018.10.25
// Author: Hideyasu Imase
//--------------------------------------------------------------------------------------
#include "pch.h"
#include "InfoWindow.h"
#include "Game.h"

using namespace DirectX;
using namespace DirectX::SimpleMath;

InfoWindow::InfoWindow()
	: m_game(nullptr), m_highScore(nullptr), m_score(nullptr), m_powerup(nullptr), m_jump(nullptr), m_life(nullptr), m_round(nullptr)
{
}

void InfoWindow::Initialize(Game * game)
{
	// �e�N�X�`���̓ǂݍ���
	CreateWICTextureFromFile(game->GetDevice(), L"Resources\\Textures\\bg01.png", nullptr, m_bg01Texture.GetAddressOf());
	CreateWICTextureFromFile(game->GetDevice(), L"Resources\\Textures\\texture01.png", nullptr, m_texture01.GetAddressOf());

	m_game = game;

	// �n�C�X�R�A�^�X�N�o�^
	m_highScore = GetTaskManager()->AddTask<Score>(this);
	m_highScore->Initialize(game, m_texture01.Get(), 24, 24, "HIGH SCORE", Color(191 / 255.0f, 194 / 255.0f, 245 / 255.0f), Colors::Yellow, 0.2f);

	// �X�R�A�^�X�N�o�^
	m_score = GetTaskManager()->AddTask<Score>(this);
	m_score->Initialize(game, m_texture01.Get(), 24, 24 * 4, "1P", Colors::Red, Colors::White, 0.5f);

	// �p���[�A�b�v�擾�^�X�N�o�^
	m_powerup = GetTaskManager()->AddTask<PartsInfo>(this);
	m_powerup->Initialize(game, m_texture01.Get(), 24, 24 * 21, PartsInfo::POWER_PARTS);

	// �W�����v�p�[�c�擾�^�X�N�o�^
	m_jump = GetTaskManager()->AddTask<PartsInfo>(this);
	m_jump->Initialize(game, m_texture01.Get(), 24, 24 * 25, PartsInfo::JUMP_PARTS);

	// �c�@���^�X�N�o�^
	m_life = GetTaskManager()->AddTask<Life>(this);
	m_life->Initialize(game, m_texture01.Get(), 24, 24 * 28);

	// ���E���h���^�X�N�o�^
	m_round = GetTaskManager()->AddTask<Round>(this);
	m_round->Initialize(game, m_texture01.Get(), 24 * 6, 24 * 28);
}

void InfoWindow::Render()
{
	// ���E�C���h�E�̔w�i�̕\��
	m_game->GetSpriteBatch()->Draw(m_bg01Texture.Get(), Vector2(0, 0));
}
