﻿//--------------------------------------------------------------------------------------
// File: Blink.h
//
// 点滅管理クラス
//
// Date: 2018.10.18
// Author: Hideyasu Imase
//--------------------------------------------------------------------------------------
#pragma once

#include "TaskManager.h"

class Blink : public Task  
{
	// 点滅フラグ
	bool m_blinkFlag;

	// 点滅時間
	float m_blinkTime;

	// 間隔（単位：秒）
	float m_interval;

	// 停止フラグ
	bool m_stopFlag;

public:
	// コンストラクタ
	Blink();

	// 初期化関数
	void Initialize(float interval);

	// 更新関数
	bool Update(float elapsedTime) override;

	// 点滅状態の取得関数
	bool GetState();

	// リセット関数
	// flagには初期状態を渡してください
	void Reset(bool flag);

	// 点滅をスタートする関数
	void Start();

	// 点滅を停止する関数
	void Stop();
};
