﻿//
// Game.h
//

#pragma once

#include "DeviceResources.h"
#include "StepTimer.h"

#include "GameWindow.h"
#include "InfoWindow.h"
#include "EffectMask.h"
#include "Title.h"
#include "Adx2.h"

// A basic game implementation that creates a D3D11 device and
// provides a game loop.
class Game : public DX::IDeviceNotify
{
public:

    Game();

	~Game();

    // Initialization and management
    void Initialize(HWND window, int width, int height);

    // Basic game loop
    void Tick();

    // IDeviceNotify
    virtual void OnDeviceLost() override;
    virtual void OnDeviceRestored() override;

    // Messages
    void OnActivated();
    void OnDeactivated();
    void OnSuspending();
    void OnResuming();
    void OnWindowSizeChanged(int width, int height);

    // Properties
    void GetDefaultSize( int& width, int& height ) const;

	void ChangeFullscreen(BOOL flag);

	void ExitGame();

private:

    void Update(DX::StepTimer const& timer);
    void Render();

    void Clear();

    void CreateDeviceDependentResources();
    void CreateWindowSizeDependentResources();

    // Device resources.
    std::unique_ptr<DX::DeviceResources>    m_deviceResources;

    // Rendering loop timer.
    DX::StepTimer                           m_timer;

	// キーボード
	std::unique_ptr<DirectX::Keyboard> m_keyboard;

	// マウス
	std::unique_ptr<DirectX::Mouse> m_mouse;

	// コモンステート
	std::unique_ptr<DirectX::CommonStates> m_states;

	// スプライトバッチ
	std::unique_ptr<DirectX::SpriteBatch> m_sprites;

	// スプライトフォント
	std::unique_ptr<DirectX::SpriteFont> m_font;

	// ゲーム画面のビューポート
	D3D11_VIEWPORT m_viewportGame;

	// 情報画面のビューポート
	D3D11_VIEWPORT m_viewportInfo;

	// タスクマネージャー（ゲーム画面用）
	TaskManager m_gameTM;

	// タスクマネージャー（情報画面用）
	TaskManager m_infoTM;

	// ゲームウインドウ
	GameWindow* m_gameWindow;

	// 情報ウインドウ
	InfoWindow* m_InfoWindow;

	// タイトル
	Title m_title;

	// 画面のエフェクト
	std::unique_ptr<EffectMask> m_effectMask;

public:
	ID3D11Device* GetDevice();
	ID3D11DeviceContext* GetContext();
	DirectX::CommonStates* GetStates();
	DirectX::SpriteBatch* GetSpriteBatch();
	DirectX::SpriteFont* GetSpriteFont();
	InfoWindow* GetInfoWindow() { return m_InfoWindow; };
	EffectMask* GetEffectMask() { return m_effectMask.get(); }
	DX::DeviceResources* GetDeviceResources() { return m_deviceResources.get(); }
};