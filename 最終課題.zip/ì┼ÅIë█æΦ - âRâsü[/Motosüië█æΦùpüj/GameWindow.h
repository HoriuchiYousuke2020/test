﻿//--------------------------------------------------------------------------------------
// File: GameWindow.h
//
// ゲーム画面クラス
//
// Date: 2018.11.4
// Author: Hideyasu Imase
//--------------------------------------------------------------------------------------
#pragma once

#include "DebugCamera.h"
#include "GridFloor.h"
#include "TaskManager.h"
#include "Bg.h"
#include "CollisionManager.h"

class Game;
class Stage;

class GameWindow : public Task
{
public:
	// 画面サイズ
	static const int SCREEN_W = 960;
	static const int SCREEN_H = 720;

	// ラウンド数
	static const int ROUND_MAX;

	// ゲームステート
	enum GAME_STATE
	{
		STATE_TITLE,		// タイトル画面
		STATE_PARTS_SELECT,	// パーツ選択画面
		STATE_START,		// 開始
		STATE_GAME,			// ゲーム中
		STATE_AGAIN,		// 死んだので再チャレンジ
		STATE_NEXT,			// 次のステージへ
		STATE_GAMEOVER,		// ゲームオーバー
	};

	// 描画順
	enum OT_PRIORITY
	{
		OT_TOP,			// 一番手前（２Ⅾ表示やエフェクトで使用） 
		OT_OBJECT,		// 床の上のオブジェクト
		OT_SHADOW,		// オブジェクトの影
		OT_STAGE,		// ステージ
		OT_FALL,		// 落下オブジェクト
		OT_BG,			// 背景
	};

	// 方向
	enum DIR
	{
		UP, LEFT, DOWN, RIGHT
	};

	// パーツ選択画面用
	enum SELECT_PARTS_KIND
	{
		POWERUP,	// パワーアップパーツ
		JUMP,		// ジャンプパーツ
	};

	// 方向に対応した角度
	static const float DIR_ANGLE[];

	// 重力
	static const float GRAVITY;

	// 落下速度
	static const float FALL_SPEED;

	// 落下したオブジェクトが画面から消える距離
	static const float FALL_DISTANCE;

	// 落下中のオブジェクトの回転速度
	static const float FALL_ROTATE_SPEED;

	// ハイスコアの初期値
	static const int HIGH_SCORE;

private:
	// キーボードトラッカー
	DirectX::Keyboard::KeyboardStateTracker m_tracker;

	// ゲームオブジェクトへのポインタ
	Game* m_game;

	// ゲームの状態
	GAME_STATE m_gameState;

	// ビュー行列
	DirectX::SimpleMath::Matrix m_view;

	// 射影行列
	DirectX::SimpleMath::Matrix m_projection;

	// 背景
	Bg* m_bg;

	// ステージ
	Stage* m_stage;

	// 衝突判定用オブジェクト
	CollisionManager* m_collisionManager;

	// ラウンド数
	int m_round;

	// 残機数
	int m_life;

	// 現在のステージで取得したパワーアップパーツ数
	int m_getPowerupParts;

	// 現在のステージで取得したジャンプパーツ数
	int m_getJumpParts;

	// パワーアップパーツ取得数
	int m_powerupParts;

	// 使用中パワーアップパーツ数
	int m_usePowerupParts;

	// ジャンプパーツ取得数
	int m_jumpParts;

	// 使用中ジャンプパーツ数
	int m_useJumpParts;

	// パーツ選択中の操作説明用の絵のテクスチャハンドル
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> m_partsSelectTexture;

	// パーツ選択画面でどのパーツを選択中のパーツ
	SELECT_PARTS_KIND m_selectParts;

	// パーツ選択画面の説明文を表示するフラグ
	bool m_selectPartsDisplayFlag;

	// ハイスコア
	int m_highScore;

	// スコア
	int m_score;

	// ハイスコア更新フラグ
	bool m_highScoreUpdate;

	// ハイスコアの点滅時間
	float m_highScoreBlinkTime;

	// ヒットエフェクト用テクスチャ
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> m_hitEffectTexture;

	// ジャンプエフェクト用テクスチャ
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> m_jumpEffectTexture;

	// 煙エフェクト用テクスチャ
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> m_smokeEffectTexture;

	//----- エフェクト用 -----//

	// エフェクト
	std::unique_ptr<DirectX::BasicEffect> m_batchEffect;

	// プリミティブバッチ
	std::unique_ptr<DirectX::PrimitiveBatch<DirectX::VertexPositionColorTexture>> m_primitiveBatch;

	// 入力レイアウト
	Microsoft::WRL::ComPtr<ID3D11InputLayout> m_inputLayout;

	// BGMハンドル
	int m_bgm;

public:
	// コンストラクタ
	GameWindow();

	// 初期化関数
	void Initialize(Game* game);

	// 更新関数
	bool Update(float elapsedTime) override;

	// 描画関数
	void Render() override;

	// ゲームオブジェクトへのポインタを取得する関数
	Game* GetGame() { return m_game; }

	// ビュー行列を取得する関数
	const DirectX::SimpleMath::Matrix& GetViewMatrix() { return m_view; }

	// 射影行列を取得する関数
	const DirectX::SimpleMath::Matrix& GetProjectionMatrix() { return m_projection; }

	// 衝突判定用オブジェクトに登録する関数
	void AddCollision(Object* object);

	// ステージタスク取得関数
	Stage* GetStage() { return m_stage; }

	// パワーアップパーツを取得した時に呼び出す関数
	void GetPowerupParts();

	// ジャンプパーツを取得した時に呼び出す関数
	void GetJumpParts();

	// 現在所持しているパワーアップパーツ数を返す関数
	int GetPowerupPartsCnt() { return m_powerupParts; }

	// 現在所持しているジャンプパーツ数を返す関数
	int GetJumpPartsCnt() { return m_jumpParts; }

	// パワーアップパーツのリセット関数
	void ResetPowerupParts();

	// ジャンプパーツのリセット関数
	void ResetJumpParts();

	// ゲームの初期化関数
	GAME_STATE InitializeGame(float elapsedTime);

	// パーツ選択画面
	GAME_STATE SelectParts(float elapsedTime);

	// ゲームをスタートさせる関数
	GAME_STATE StartGame(float elapsedTime);

	// ゲーム中の関数
	GAME_STATE PlayGame(float elapsedTime);

	// 次のステージへ
	GAME_STATE NextGame(float elapsedTime);

	// スコアを設定する関数
	void SetScore(int score);

	// スコアを取得する関数
	int GetScore();

	// エフェクト用ベーシックエフェクトを取得する関数
	DirectX::BasicEffect* GetBatchEffect() { return m_batchEffect.get(); }

	// エフェクト用プリミティブバッチを取得する関数
	DirectX::PrimitiveBatch<DirectX::VertexPositionColorTexture>* GetPrimitiveBatch() { return m_primitiveBatch.get(); }

	// エフェクト用入力レイアウトを取得する関数
	ID3D11InputLayout* GetInputLayout() { return m_inputLayout.Get(); }

	// ヒットエフェクト用テクスチャの取得関数
	ID3D11ShaderResourceView* GetHitEffectTexture() { return m_hitEffectTexture.Get(); }

	// ジャンプエフェクト用テクスチャの取得関数
	ID3D11ShaderResourceView* GetJumpEffectTexture() { return m_jumpEffectTexture.Get(); }

	// 煙エフェクト用テクスチャの取得関数
	ID3D11ShaderResourceView* GetSmokeEffectTexture() { return m_smokeEffectTexture.Get(); }

private:
	// ステージデータのファイル名を取得する関数
	wchar_t* GetStageFilename(int round);

	// 敵が全滅しているかチェックする関数
	bool CheckEnemyAllDead();

	// パーツの更新処理
	void UpdateParts(bool stageClearFlag);

	// エフェクト用リソースの初期化
	void InitializeEffectResources(Game* game);
};
