//--------------------------------------------------------------------------------------
// File: Title.cpp
//
// �^�C�g���N���X
//
// Date: 2019.1.4
// Author: Hideyasu Imase
//--------------------------------------------------------------------------------------
#include "pch.h"
#include "Title.h"
#include "Game.h"

using namespace DirectX;
using namespace DirectX::SimpleMath;

Title::Title()
	: m_game(nullptr), m_scroll(0.0f), m_displayFlag(false), m_interval(0.0f), m_counter(0.0f)
{
}

void Title::Initialize(Game * game)
{
	m_game = game;
	m_interval = 0.5f;

	// ��ʃT�C�Y���擾
	int w, h;
	game->GetDefaultSize(w, h);

	// �����_�����O�^�[�Q�b�g�p�̃e�N�X�`�����쐬
	D3D11_TEXTURE2D_DESC texDesc;
	memset(&texDesc, 0, sizeof(texDesc));
	texDesc.Usage = D3D11_USAGE_DEFAULT;
	texDesc.Format = DXGI_FORMAT_R8G8B8A8_TYPELESS;
	texDesc.BindFlags = D3D11_BIND_RENDER_TARGET | D3D11_BIND_SHADER_RESOURCE;
	texDesc.Width = w;
	texDesc.Height = h;
	texDesc.CPUAccessFlags = 0;
	texDesc.MipLevels = 1;
	texDesc.ArraySize = 1;
	texDesc.SampleDesc.Count = 1;
	texDesc.SampleDesc.Quality = 0;
	game->GetDevice()->CreateTexture2D(&texDesc, NULL, m_texture2D.GetAddressOf());

	// �����_�[�^�[�Q�b�g�r���[�̐���
	D3D11_RENDER_TARGET_VIEW_DESC rtvDesc;
	memset(&rtvDesc, 0, sizeof(rtvDesc));
	rtvDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
	rtvDesc.ViewDimension = D3D11_RTV_DIMENSION_TEXTURE2D;
	game->GetDevice()->CreateRenderTargetView(m_texture2D.Get(), &rtvDesc, m_renderTargetView.GetAddressOf());

	// �V�F�[�_�[���\�[�X�r���[�̐���
	D3D11_SHADER_RESOURCE_VIEW_DESC srvDesc;
	memset(&srvDesc, 0, sizeof(srvDesc));
	srvDesc.Format = rtvDesc.Format;
	srvDesc.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D;
	srvDesc.Texture2D.MipLevels = 1;
	game->GetDevice()->CreateShaderResourceView(m_texture2D.Get(), &srvDesc, m_shaderResourceView.GetAddressOf());

	// �e�N�X�`���̓ǂݍ���
	CreateWICTextureFromFile(m_game->GetDevice(), L"Resources\\Textures\\title.png", nullptr, m_titleTexture.GetAddressOf());
	CreateWICTextureFromFile(m_game->GetDevice(), L"Resources\\Textures\\title_tile.png", nullptr, m_tileTexture.GetAddressOf());
	CreateWICTextureFromFile(m_game->GetDevice(), L"Resources\\Textures\\push_space.png", nullptr, m_pushSpaceTexture.GetAddressOf());
}

void Title::Update(float elapsedTime)
{
	// �_��
	m_counter += elapsedTime;
	if (m_counter >= m_interval)
	{
		m_counter = 0.0f;
		if (m_displayFlag)
		{
			m_displayFlag = false;
		}
		else
		{
			m_displayFlag = true;
		}
	}

	// �X�N���[��
	m_scroll += 0.5f;
	if (m_scroll >= 100.0f) m_scroll -= 100.0f;
}

ID3D11ShaderResourceView* Title::Render()
{
	auto renderTarget = m_game->GetDeviceResources()->GetRenderTargetView();
	auto depthStencil = m_game->GetDeviceResources()->GetDepthStencilView();

	// �p�ӂ����e�N�X�`���Ƀ����_�����O
	//m_game->GetContext()->ClearRenderTargetView(m_renderTargetView.Get(), Colors::Black);
	//m_game->GetContext()->ClearDepthStencilView(depthStencil, D3D11_CLEAR_DEPTH | D3D11_CLEAR_STENCIL, 1.0f, 0);
	m_game->GetContext()->OMSetRenderTargets(1, m_renderTargetView.GetAddressOf(), depthStencil);

	m_game->GetSpriteBatch()->Begin(SpriteSortMode_Deferred, m_game->GetStates()->NonPremultiplied());

	// ���̃^�C���̕`��
	for (int j = 0; j < 9; j++)
	{
		for (int i = 0; i < 14; i++)
		{
			m_game->GetSpriteBatch()->Draw(m_tileTexture.Get(), Vector2(i * 100.0f - m_scroll, (j - 1) * 100.0f + m_scroll));
		}
	}

	// �^�C�g���̕`��
	RECT destRect = { 0, 0, 1280, 720 };
	m_game->GetSpriteBatch()->Draw(m_titleTexture.Get(), destRect);

	// PUSH START�̕`��
	if (m_displayFlag)
	{
		m_game->GetSpriteBatch()->Draw(m_pushSpaceTexture.Get(), Vector2(430, 570));
	}

	m_game->GetSpriteBatch()->End();

	// �����_�[�^�[�Q�b�g�����ɖ߂�
	m_game->GetContext()->OMSetRenderTargets(1, &renderTarget, depthStencil);

	return m_shaderResourceView.Get();
}
