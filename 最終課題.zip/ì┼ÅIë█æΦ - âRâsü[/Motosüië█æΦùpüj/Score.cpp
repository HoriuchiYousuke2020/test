//--------------------------------------------------------------------------------------
// File: Score.cpp
//
// �X�R�A��\������N���X
//
// Date: 2018.10.18
// Author: Hideyasu Imase
//--------------------------------------------------------------------------------------
#include "pch.h"
#include "Score.h"

using namespace DirectX;
using namespace DirectX::SimpleMath;

Score::Score()
	: m_blink(nullptr)
{
}

Score::~Score()
{
}

void Score::Initialize(Game * game, ID3D11ShaderResourceView* texture, int x, int y, const char * title, DirectX::FXMVECTOR titleColor, DirectX::FXMVECTOR scoreColor, float blinkTime)
{
	m_titleMoji.Initialize(game, texture, x, y, title, titleColor);
	m_scoreMoji.Initialize(game, texture, x + 24, y + 24, "      00", scoreColor);

	// �_�ŊǗ��^�X�N��o�^
	m_blink = GetTaskManager()->AddTask<Blink>(this);

	// �_�ŊԊu�̐ݒ�
	m_blink->Initialize(blinkTime);
}

void Score::Render()
{
	if (m_blink->GetState())
	{
		m_titleMoji.Draw();
	}
	m_scoreMoji.Draw();
}

void Score::SetScore(int score)
{
	char str[] = "      00";
	if (score > 99999999) score = 99999999;
	int pos = 7;
	while (score && pos >= 0)
	{
		str[pos] = '0' + score % 10;
		score /= 10;
		pos--;
	}
	m_scoreMoji.SetStr(str);
}

void Score::BlinkTitle(bool flag)
{
	if (flag)
	{
		m_blink->Start();
	}
	else
	{
		m_blink->Stop();
		m_blink->Reset(true);
	}
}
