﻿//--------------------------------------------------------------------------------------
// File: Life.h
//
// 残機数を表示するクラス
//
// Date: 2018.10.18
// Author: Hideyasu Imase
//--------------------------------------------------------------------------------------
#pragma once

#include "TaskManager.h"

class Game;

class Life : public Task
{
	// 絵のサイズ
	static const int SIZE = 24;

	// ゲームオブジェクトへのポインタ
	Game* m_game;

	// テクスチャハンドル
	ID3D11ShaderResourceView* m_texture;

	// 表示位置
	int m_x, m_y;

	// 残機数
	int m_life;

public:
	// コンストラクタ
	Life();

	// 初期化関数
	void Initialize(Game* game, ID3D11ShaderResourceView* texture, int x, int y);

	// 描画関数
	void Render() override;

	// 残機数の取得
	int GetLife() { return m_life; }

	// 残機数の設定
	void SetLife(int life) { m_life = life; }
};