//--------------------------------------------------------------------------------------
// File: Round.cpp
//
// ���E���h��\������N���X
//
// Date: 2018.10.18
// Author: Hideyasu Imase
//--------------------------------------------------------------------------------------
#include "pch.h"
#include "Round.h"
#include "Game.h"

using namespace DirectX;
using namespace DirectX::SimpleMath;

Round::Round()
{
}

void Round::Initialize(Game * game, ID3D11ShaderResourceView * texture, int x, int y)
{
	m_moji.Initialize(game, texture, x, y, "ROUND 0");
}

void Round::Render()
{
	m_moji.Draw();
}

void Round::SetRound(int round)
{
	char str[] = "ROUND  ";
	if (round > 99) round = 99;
	str[6] = '0' + round % 10;
	if (round / 10 != 0) str[5] = '0' + round / 10;
	m_moji.SetStr(str);
}
