﻿//--------------------------------------------------------------------------------------
// File: Round.h
//
// ラウンドを表示するクラス
//
// Date: 2018.10.18
// Author: Hideyasu Imase
//--------------------------------------------------------------------------------------
#pragma once

#include "TaskManager.h"
#include "Moji.h"

class Game;

class Round : public Task
{
	// 文字列
	Moji m_moji;

public:
	// コンストラクタ
	Round();

	// 初期化関数
	void Initialize(Game* game, ID3D11ShaderResourceView* texture, int x, int y);

	// 描画関数
	void Render() override;

	// ラウンド数の設定関数
	void SetRound(int round);
};