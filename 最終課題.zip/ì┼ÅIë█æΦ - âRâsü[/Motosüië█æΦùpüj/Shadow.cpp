//--------------------------------------------------------------------------------------
// File: Shadow.cpp
//
// �e�N���X�iObject�ɕt����e�j
//
// Date: 2018.12.5
// Author: Hideyasu Imase
//--------------------------------------------------------------------------------------
#include "pch.h"
#include "Shadow.h"
#include "Game.h"
#include "GameWindow.h"
#include "Object.h"

using namespace DirectX;
using namespace DirectX::SimpleMath;

Shadow::Shadow()
	: m_gameWindow(nullptr), m_active(true)
{
	// �`�揇�̐ݒ�
	SetOt(GameWindow::OT_SHADOW);
}

void Shadow::Initialize(GameWindow * gameWindow, DirectX::Model * model)
{
	m_gameWindow = gameWindow;
	m_model = model;

	// �u�����h�X�e�[�g�쐬�i���Z�����j
	D3D11_BLEND_DESC bd;
	ZeroMemory(&bd, sizeof(D3D11_BLEND_DESC));
	bd.AlphaToCoverageEnable = FALSE;
	bd.IndependentBlendEnable = FALSE;
	bd.RenderTarget[0].BlendEnable = TRUE;
	bd.RenderTarget[0].SrcBlend = D3D11_BLEND_ZERO;
	bd.RenderTarget[0].DestBlend = D3D11_BLEND_INV_SRC_COLOR;
	bd.RenderTarget[0].BlendOp = D3D11_BLEND_OP_ADD;
	bd.RenderTarget[0].SrcBlendAlpha = D3D11_BLEND_ZERO;
	bd.RenderTarget[0].DestBlendAlpha = D3D11_BLEND_ONE;
	bd.RenderTarget[0].BlendOpAlpha = D3D11_BLEND_OP_ADD;
	bd.RenderTarget[0].RenderTargetWriteMask = D3D11_COLOR_WRITE_ENABLE_ALL;
	m_gameWindow->GetGame()->GetDevice()->CreateBlendState(&bd, m_blendState.GetAddressOf());
}

void Shadow::Render()
{
	if (!m_gameWindow || !m_model || !m_active) return;

	Game* game = m_gameWindow->GetGame();

	// �e�̐^���ɉe��\������
	Object* object = static_cast<Object*>(GetParent());
	const Vector3& pos = object->GetPosition();

	Matrix world = Matrix::CreateTranslation(Vector3(pos.x, 0.0f, pos.z));
	m_model->Draw(game->GetContext(), *game->GetStates()
			, world
			, m_gameWindow->GetViewMatrix()
			, m_gameWindow->GetProjectionMatrix()
		, false, [&]()
	{
		// �u�����h�����Z�����ɂ��[�x�o�b�t�@�͎g�p�����`�悷��
		game->GetContext()->OMSetBlendState(m_blendState.Get(), nullptr, 0xffffffff);
		game->GetContext()->OMSetDepthStencilState(game->GetStates()->DepthNone(), 0);
	});
}
