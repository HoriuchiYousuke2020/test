﻿/*===========================================================================*
 *  Header file for Atom CueSheet Binary
 *  Project          : Motos
 *  Tool Ver.        : CRI Atom Craft LE Ver.2.30.07
 *  File Path        : C:/Users/hideyasu/Documents/CriAtomCraft/Motos/Public/WorkUnit_0/MotosCueSheet.acb
 *  File Name        : MotosCueSheet.acb
 *  File Size        : 1,804,288 bytes
 *  Date Time        : 2019/01/13 23:41
 *  Target           : Public
 *  Cues             : 7
 *  CueSheet Comment : 
 *  Stream Awb Path  : 
 *===========================================================================*/

#define CRI_MOTOSCUESHEET_CUENUM (7)

/* AISAC Control List (AISAC Control ID) */
// No AISAC Control


/* Cue List (Cue ID) */
#define CRI_MOTOSCUESHEET_CURSOR     ( 1) /*   */
#define CRI_MOTOSCUESHEET_FALL       ( 2) /*   */
#define CRI_MOTOSCUESHEET_GET        ( 3) /*   */
#define CRI_MOTOSCUESHEET_HIT        ( 4) /*   */
#define CRI_MOTOSCUESHEET_JUMP       ( 5) /*   */
#define CRI_MOTOSCUESHEET_BGM        ( 6) /*   */
#define CRI_MOTOSCUESHEET_HIGHSCORE  ( 7) /*   */

/* Block List (Block Index) */

/* end of file */

