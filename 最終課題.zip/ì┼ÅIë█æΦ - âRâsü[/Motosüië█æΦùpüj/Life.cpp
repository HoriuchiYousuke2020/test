//--------------------------------------------------------------------------------------
// File: Life.cpp
//
// �c�@����\������N���X
//
// Date: 2018.10.18
// Author: Hideyasu Imase
//--------------------------------------------------------------------------------------
#include "pch.h"
#include "Life.h"
#include "Game.h"

using namespace DirectX;
using namespace DirectX::SimpleMath;

Life::Life()
	: m_game(nullptr), m_texture(nullptr), m_x(0), m_y(0), m_life(0)
{
}

void Life::Initialize(Game * game, ID3D11ShaderResourceView * texture, int x, int y)
{
	m_game = game;
	m_texture = texture;
	m_x = x;
	m_y = y;
}

void Life::Render()
{
	if (!m_game || !m_texture) return;

	RECT srcRect = { 0 * SIZE, 5 * SIZE, 1 * SIZE, 6 * SIZE };
	for (int i = 0; i < m_life; i++)
	{
		m_game->GetSpriteBatch()->Draw(m_texture, Vector2((float)m_x + SIZE * i, (float)m_y), &srcRect);
	}
}
