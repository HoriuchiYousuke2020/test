//--------------------------------------------------------------------------------------
// File: EffectMask.cpp
//
// ��ʐ؂�ւ��p�̃}�X�N�\���N���X
//
// Date: 2018.12.28
// Author: Hideyasu Imase
//--------------------------------------------------------------------------------------
#include "pch.h"
#include "EffectMask.h"
#include "Game.h"
#include "GameWindow.h"
#include "File.h"

using namespace DirectX;
using namespace DirectX::SimpleMath;

EffectMask::EffectMask()
	: m_game(nullptr), m_interval(0.0f), m_rate(0.0f), m_open(false), m_color(Colors::White)
{
}

void EffectMask::Initialize(Game * game, float interval)
{
	m_game = game;
	m_interval = interval;

	// �s�N�Z���V�F�[�_�[�̓ǂݍ��݂ƍ쐬
	File* ps = new File(L"Resources\\Shaders\\PixelShader.cso");
	game->GetDevice()->CreatePixelShader((void*)ps->data, ps->length, NULL, m_pixelShader.GetAddressOf());
	delete ps;

	// �萔�o�b�t�@�̒�`
	D3D11_BUFFER_DESC cBufferDesc;
	cBufferDesc.Usage = D3D11_USAGE_DYNAMIC;
	cBufferDesc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
	cBufferDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
	cBufferDesc.MiscFlags = 0;

	// �萔�o�b�t�@�̍쐬
	cBufferDesc.ByteWidth = sizeof(cbChangesEveryFrame);
	game->GetDevice()->CreateBuffer(&cBufferDesc, NULL, m_cbBuffer.GetAddressOf());
}

void EffectMask::Update(float elapsedTime)
{
	if (m_open)
	{
		// �I�[�v��
		m_rate += elapsedTime / m_interval;
		if (m_rate > 1.0f) m_rate = 1.0f;
	}
	else
	{
		// �N���[�Y
		m_rate -= elapsedTime / m_interval;
		if (m_rate < 0.0f) m_rate = 0.0f;
	}
}

void EffectMask::Draw(ID3D11ShaderResourceView* texture)
{
	RECT rect;
	int w, h;

	// �J���Ă���ꍇ�͕`��͂��Ȃ�
	if (m_rate == 1.0f) return;

	// ��ʃT�C�Y���擾���ă}�X�N�̋�`��ݒ肷��
	m_game->GetDefaultSize(w, h);
	rect.left = 0;
	rect.top = 0;
	rect.right = w;
	rect.bottom = h;

	// �萔�o�b�t�@�̒l��ݒ�
	m_cbChangesEveryFrame.radius = m_rate;
	m_cbChangesEveryFrame.aspectRatio = w / (float)h;

	m_game->GetSpriteBatch()->Begin(SpriteSortMode_Deferred, nullptr, nullptr, nullptr, nullptr, [&]()
	{
		// �萔�o�b�t�@�ւ̏�������
		D3D11_MAPPED_SUBRESOURCE mappedResource;
		m_game->GetContext()->Map(m_cbBuffer.Get(), 0, D3D11_MAP_WRITE_DISCARD, 0, &mappedResource);
		CopyMemory(mappedResource.pData, &m_cbChangesEveryFrame, sizeof(cbChangesEveryFrame));
		m_game->GetContext()->Unmap(m_cbBuffer.Get(), 0);

		// �s�N�Z���V�F�[�_�[�ɒ萔�o�b�t�@��ݒ�
		ID3D11Buffer* buffers[] = { m_cbBuffer.Get() };
		m_game->GetContext()->PSSetConstantBuffers(0, 1, buffers);

		// �s�N�Z���V�F�[�_�[��ݒ�
		m_game->GetContext()->PSSetShader(m_pixelShader.Get(), nullptr, 0);
	});

	// �}�X�N�̕`��
	m_game->GetSpriteBatch()->Draw(texture, rect, m_color);

	m_game->GetSpriteBatch()->End();
}

void EffectMask::Open()
{
	m_open = true;
}

void EffectMask::Close()
{
	m_open = false;
}

bool EffectMask::IsOpen()
{
	if (m_open && m_rate == 1.0f) return true;
	return false;
}

bool EffectMask::IsClose()
{
	if (!m_open && m_rate == 0.0f) return true;
	return false;
}
