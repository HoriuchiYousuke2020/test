//--------------------------------------------------------------------------------------
// File: JumpEffect.cpp
//
// �W�����v���̃G�t�F�N�g�\���N���X
//
// Date: 2019.1.5
// Author: Hideyasu Imase
//--------------------------------------------------------------------------------------
#include "pch.h"
#include "JumpEffect.h"
#include "Game.h"
#include "GameWindow.h"
#include "SmokeEffect.h"

using namespace DirectX;
using namespace DirectX::SimpleMath;

// �G�t�F�N�g�\������
const float JumpEffect::DISPLAY_TIME = 0.15f;

JumpEffect::JumpEffect()
	: m_gameWindow(nullptr), m_timer(0.0f)
{
	SetOt(GameWindow::OT_TOP);
}

void JumpEffect::Initialize(GameWindow * gameWindow, DirectX::SimpleMath::Vector3 pos)
{
	m_gameWindow = gameWindow;
	m_pos = pos;
	m_timer = DISPLAY_TIME;

	// ���̑��x�x�N�g��
	Vector3 v(0.0f, 0.02f, 0.05f);

	// ���̃G�t�F�N�g�������ɂW�����ɔ���������
	Matrix rotY = Matrix::CreateRotationY(XMConvertToRadians(45.0f));
	for (int i = 0; i < 8; i++)
	{
		SmokeEffect* smokeEffect = GetTaskManager()->AddTask<SmokeEffect>();
		// ���̃G�t�F�N�g���d�Ȃ�Ȃ��悤��Y���W���������炷
		Vector3 pos = Vector3(m_pos.x, i * 0.01f, m_pos.z);
		smokeEffect->Initialize(m_gameWindow, pos, v);
		v = Vector3::Transform(v, rotY);
	}
}

bool JumpEffect::Update(float elapsedTime)
{
	// ���ԂɂȂ�����^�X�N�͏�����
	m_timer -= elapsedTime;
	if (m_timer <= 0.0f) return false;
	return true;
}

void JumpEffect::Render()
{
	// ���_���
	VertexPositionColorTexture vertex[4] =
	{
		VertexPositionColorTexture(XMFLOAT3( 1.0f, 0.01f,  1.0f), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), XMFLOAT2(0.0f, 0.0f)),
		VertexPositionColorTexture(XMFLOAT3(-1.0f, 0.01f,  1.0f), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), XMFLOAT2(1.0f, 0.0f)),
		VertexPositionColorTexture(XMFLOAT3(-1.0f, 0.01f, -1.0f), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), XMFLOAT2(1.0f, 1.0f)),
		VertexPositionColorTexture(XMFLOAT3( 1.0f, 0.01f, -1.0f), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), XMFLOAT2(0.0f, 1.0f)),
	};
	Game* game = m_gameWindow->GetGame();

	// ���Z����
	game->GetContext()->OMSetBlendState(game->GetStates()->NonPremultiplied(), nullptr, 0xFFFFFFFF);
	// �[�x�o�b�t�@����
	game->GetContext()->OMSetDepthStencilState(game->GetStates()->DepthDefault(), 0);
	// �J�����O�͍�����
	game->GetContext()->RSSetState(game->GetStates()->CullCounterClockwise());

	float scale = 0.5f + 0.5f * (1.0f - m_timer / DISPLAY_TIME);
	Matrix world = Matrix::CreateScale(scale) * Matrix::CreateTranslation(m_pos);
	m_gameWindow->GetBatchEffect()->SetWorld(world);
	m_gameWindow->GetBatchEffect()->SetView(m_gameWindow->GetViewMatrix());
	m_gameWindow->GetBatchEffect()->SetProjection(m_gameWindow->GetProjectionMatrix());
	m_gameWindow->GetBatchEffect()->SetTexture(m_gameWindow->GetJumpEffectTexture());
	m_gameWindow->GetBatchEffect()->Apply(game->GetContext());
	game->GetContext()->IASetInputLayout(m_gameWindow->GetInputLayout());

	m_gameWindow->GetPrimitiveBatch()->Begin();
	m_gameWindow->GetPrimitiveBatch()->DrawQuad(vertex[0], vertex[1], vertex[2], vertex[3]);
	m_gameWindow->GetPrimitiveBatch()->End();
}
